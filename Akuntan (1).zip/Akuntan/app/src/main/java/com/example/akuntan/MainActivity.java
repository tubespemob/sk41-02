package com.example.akuntan;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView imageViewJurnal = findViewById(R.id.imageView3);

        imageViewJurnal.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view){
                Intent intent = new Intent(MainActivity.this, Jurnal.class);
                startActivity(intent);
            }
        });

        ImageView imageViewLaporan = findViewById(R.id.imageView4);

        imageViewLaporan.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view){
                Intent intent = new Intent(MainActivity.this, Laporan.class);
                startActivity(intent);
            }
        });

        ImageView imageViewConverter = findViewById(R.id.imageView5);

        imageViewConverter.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view){
                Intent intent = new Intent(MainActivity.this, Laporan.class);
                startActivity(intent);
            }
        });

        ImageView imageViewKalkulator = findViewById(R.id.imageView2);

        imageViewKalkulator.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view){
                Intent intent = new Intent(MainActivity.this, Laporan.class);
                startActivity(intent);
            }
        });

        ImageView imageViewPengaturan = findViewById(R.id.imageView6);

        imageViewPengaturan.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view){
                Intent intent = new Intent(MainActivity.this, Laporan.class);
                startActivity(intent);
            }
        });

        ImageView imageViewAbout = findViewById(R.id.imageView7);

        imageViewAbout.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view){
                Intent intent = new Intent(MainActivity.this, Laporan.class);
                startActivity(intent);
            }
        });



    }


}
