package com.example.akuntan;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class Laporan extends AppCompatActivity {


    protected void onCreat(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_junal);

        getSupportActionBar().setTitle("Akuntan");
    }
}
